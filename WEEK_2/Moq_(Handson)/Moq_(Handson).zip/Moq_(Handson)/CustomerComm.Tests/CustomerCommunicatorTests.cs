using NUnit.Framework;
using Moq;
using CustomerCommLib;

namespace CustomerComm.Tests
{
    [TestFixture]
    public class CustomerCommunicatorTests
    {
        private Mock<IMailSender> _mockMailSender;
        private CustomerCommunicator _customerCommunicator;

        [OneTimeSetUp]
        public void Init()
        {
            _mockMailSender = new Mock<IMailSender>();
            _mockMailSender.Setup(m => m.SendMail(It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            _customerCommunicator = new CustomerCommunicator(_mockMailSender.Object);
        }

        [TestCase]
        public void SendMailToCustomer_ReturnsTrue()
        {
            var result = _customerCommunicator.SendMailToCustomer();
            Assert.IsTrue(result);
        }
    }
}
