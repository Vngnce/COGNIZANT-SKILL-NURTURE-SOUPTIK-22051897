namespace CustomerCommLib
{
    public class CustomerCommunicator
    {
        private IMailSender _mailSender;

        public CustomerCommunicator(IMailSender mailSender)
        {
            _mailSender = mailSender;
        }

        public bool SendMailToCustomer()
        {
            string email = "cust123@abc.com";
            string message = "Some Message";
            return _mailSender.SendMail(email, message);
        }
    }
}
